# Português (PT_BR)

Este Plug-in foi desenvolvido para gerar "Ordem de Serviço" baseado nos dados do ticket.

Para instalar o Plug-in siga os passos abaixo:

- Faça o download do projeto e extraia na pasta "plugins" que encontra-se na raiz do GLPI;
- Acesse o GLPI, vá em Configurar > Plug-ins;
- Encontre o Plug-in "OS" na lista e clique em Instalar;
- Clique em Habilitar.

Configurar:

- Após instalar e habilitar o Plug-in, surgirá um ítem "Ordem de Serviços" no menu Plug-ins.
- Configure as informações solicitadas que serão exibidas na impressão.

Modo de usar:

- Dentro de cada Ticket surgirá uma aba "Ordem de Serviço" com duas opções:
- Gerar OS - Entidade: Nessa opção a impressão baseará nas informações da Entidade com nome da entidade, endereço, telefone, etc.
- Gerar OS - Cliente: Na opção de cliente a impressão sairá com informações do usuário que abriu o chamado.

# FIM (PT_BR) 
